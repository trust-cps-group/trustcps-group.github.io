---
subheadline: "Univ. assistant"
title:  ""
first: "Emery"
family: "Neufeld"
mail: ""
role: "PhD Student"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/296/4906.html"
hasgithub: "yes"
github: "https://github.com/lexeree"
image:
  thumb: "people_pictures/neufeld.png"
  homepage: "people_pictures/neufeld.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
