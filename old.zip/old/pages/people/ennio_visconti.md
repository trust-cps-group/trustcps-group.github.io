---
subheadline: "Univ. assistant"
title:  ""
first: "Ennio"
family: "Visconti"
mail: ""
role: "PhD Student"
hasdblp: "yes"
dblp:    "https://dblp.uni-trier.de/pid/253/6180.html"
hasgscholar: "yes"
gscholar: "https://scholar.google.de/citations?user=1-fqjpsAAAAJ"
hasgithub: "yes"
github: "https://github.com/ennioVisco"
hasscopus: "yes"
scopus: "https://www.scopus.com/authid/detail.uri?authorId=57215278886"
image:
  thumb: "people_pictures/visconti.png"
  homepage: "people_pictures/visconti.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
