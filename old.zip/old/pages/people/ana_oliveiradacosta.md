---
subheadline: ""
title:  ""
first: "Ana"
family: "Oliveira da Costa"
mail: ""
role: "PhD Student"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/212/3834.html"
image:
  thumb: "people_pictures/oli_costa.png"
  homepage: "people_pictures/oli_costa.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
