---
subheadline: "Univ. assistant"
title:  ""
first: "Eleonora"
family: "Nesterini"
role: "PhD Student"
mail: ""
image:
  thumb: "people_pictures/nesterini.png"
  homepage: "people_pictures/nesterini.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
