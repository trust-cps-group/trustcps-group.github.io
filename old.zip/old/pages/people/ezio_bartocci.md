---
subheadline: "Univ.-Prof"
title:  "Univ.-Prof. Dr."
first: "Ezio"
family: "Bartocci"
role:   "Group Leader"
prio: "1"
mail: ""
website: "http://www.eziobartocci.com/"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/b/EzioBartocci.html"
hasgscholar: "yes"
gscholar: "https://scholar.google.de/citations?user=EeK43rAAAAAJ"
hasgithub: "yes"
github: "https://github.com/eziobartocci80"
hasscopus: "yes"
scopus: "https://www.scopus.com/authid/detail.uri?authorId=14053557900"
image:
  thumb: "people_pictures/bartocci.png"
  homepage: "people_pictures/bartocci.png"
---

<!--more-->

Ezio Bartocci
