---
subheadline: "Univ. assistant"
title:  ""
first: "Drishti"
family: "Yadav"
mail: ""
role: "PhD Student"
hasgscholar: "yes"
gscholar: "https://scholar.google.de/citations?user=5h2LnBcAAAAJ"
hasscopus: "yes"
scopus: "https://www.scopus.com/authid/detail.uri?authorId=57215595961"
image:
  thumb: "people_pictures/drishti.png"
  homepage: "people_pictures/drishti.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
