---
subheadline: "Project Assistant"
title:  ""
first: "Francesco"
family: "Pontiggia"
mail: ""
role: "Project Assistant"
hasgithub: "yes"
github: "https://github.com/francescopont"
image:
  thumb: "people_pictures/pontiggia.png"
  homepage: "people_pictures/pontiggia.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.