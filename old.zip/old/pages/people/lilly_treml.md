---
subheadline: "Univ. assistant"
title:  ""
first: "Lilly"
family: Treml
mail: ""
role: "PhD Student"
hasscopus: "yes"
scopus: "https://www.scopus.com/authid/detail.uri?authorId=57221691875"
image:
  thumb: "people_pictures/treml.png"
  homepage: "people_pictures/treml.png"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
