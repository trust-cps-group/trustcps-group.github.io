---
subheadline: ""
title:  "Dr."
first: "Mohamed Amin"
family: "Ben Sassi"
mail: ""
role: "Now Assistant Professor at MedTech, Tunisia"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/22/8910.html"
image:
  thumb: "people_pictures/bensassi.jpg"
  homepage: "https://sites.google.com/site/bensassipersonalpage/"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
