---
subheadline: ""
title:  "Dr."
first: "Konstantin"
family: "Selyunin"
mail: ""
role: "Now Development Engineer at Bosch, Austria"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/159/1606.html"
image:
  thumb: "people_pictures/selyunin.png"
  homepage: "https://selyunin.ru/"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
