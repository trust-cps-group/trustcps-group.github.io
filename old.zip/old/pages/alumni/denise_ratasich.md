---
subheadline: ""
title:  "Dr."
first: "Denise"
family: "Ratasich"
mail: ""
role: "Now Data Scientist at ÖBB, Austria"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/159/1755.html"
image:
  thumb: "people_pictures/ratasich.png"
  homepage: "https://www.linkedin.com/in/denise-ratasich-6708b689/?originalSubdomain=at"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
