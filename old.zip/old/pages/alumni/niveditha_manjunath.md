---
subheadline: ""
title:  "Dr."
first: "Niveditha"
family: "Manjunath"
role: "Now Senior System Test Engineer (DB Netz AG), Germany"
mail: ""
hasdblp: "yes"
dblp:    "https://dblp.org/pid/217/3820.html"
image:
  thumb: "people_pictures/manjunath.png"
  homepage: "https://www.linkedin.com/in/niveditha-manjunath/"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
