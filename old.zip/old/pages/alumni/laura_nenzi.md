---
subheadline: ""
title:  "Dr."
first: "Laura"
family: "Nenzi"
role:   "Now Assistant Professor at University of Trieste"
mail: ""
website: "https://lauranenzi.github.io/"
hasdblp: "yes"
dblp: "https://dblp.org/pid/131/6717.html"
hasscopus: "yes"
scopus: "https://www.scopus.com/authid/detail.uri?authorId=57194631985"
hasgscholar: "yes"
gscholar: "https://scholar.google.de/citations?user=3xNQYkkAAAAJ"
image:
  thumb: "people_pictures/laura.png"
---

<!--more-->

I am a post-doctoral researcher at Trust-CPS Group.
