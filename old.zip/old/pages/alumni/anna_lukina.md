---
subheadline: ""
title:  "Dr."
first: "Anna"
family: "Lukina"
mail: ""
role: "Now PostDoc at IST, Austria"
hasdblp: "yes"
dblp:    "https://dblp.org/pid/186/9691.html"
image:
  thumb: "people_pictures/lukina.png"
  homepage: "https://annalukina.com/"
---

<!--more-->

I am a doctoral researcher at Trust-CPS Group.
