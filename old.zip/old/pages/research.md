---
layout: research-tiles
show_meta: false
title: "Research"
subheadline: "Ongoing and past research projects"
header: no
permalink: "/research/"
teaser: "Research projects are listed in chronological order (newest first). Currently, projects are displayed by a link only, it is planned to arrange them in a grid with tiles showing a short teaser."
---
