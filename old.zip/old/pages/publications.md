---
layout: page-fullwidth
title: "Publications"
subheadline: "Our publications"
teaser: "A complete collection of work published by members of our group."
permalink: "/publications/"
header: no
---


<!--{% bibliography -q @*[year=] %}-->

{% bibliography %}

<!--
## Journal Articles

{% bibliography -q @article %}

## Book Chapters

{% bibliography -q @inbook %}

## Conferences and Workshops

{% bibliography -q @inproceedings %}

## Manuscripts

{% bibliography -q @phdthesis %}
-->
